1:"$Sreact.fragment"
2:I[92825,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"ClientSegmentRoot"]
3:I[82391,["/_next/static/chunks/7bd0d23efebd496b.js","/_next/static/chunks/4baa1d9d90d3c2ac.js","/_next/static/chunks/3e2417ea1db266df.js"],"default"]
4:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
5:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"default"]
0:{"buildId":"2QQsHoQhSzsyjHRVskuVh","rsc":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/3e2417ea1db266df.js","async":true}]],["$","$L2",null,{"Component":"$3","slots":{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","div",null,{"className":"sfx-page-in","children":["$","$L5",null,{}]}],"templateStyles":[],"templateScripts":[]}]},"serverProvidedParams":{"params":{},"promises":["$@6"]}}]]}],"loading":null,"isPartial":false}
6:"$0:rsc:props:children:1:props:serverProvidedParams:params"
