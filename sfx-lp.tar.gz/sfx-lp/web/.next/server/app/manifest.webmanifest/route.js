var R=require("../../chunks/[turbopack]_runtime.js")("server/app/manifest.webmanifest/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/node_modules_next_0e7252fa._.js")
R.c("server/chunks/_next-internal_server_app_manifest_webmanifest_route_actions_1bff3fca.js")
R.m(37648)
module.exports=R.m(37648).exports
