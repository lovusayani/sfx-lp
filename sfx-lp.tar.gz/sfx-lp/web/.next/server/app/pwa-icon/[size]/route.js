var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/pwa-icon/[size]/route.js")
R.c("server/chunks/[root-of-the-server]__214d9278._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_pwa-icon_[size]_route_actions_3958ef60.js")
R.m(45848)
module.exports=R.m(45848).exports
